NOSHU × NOUSHIN — ONLINE DEPLOYMENT VERSION

You do NOT need to edit the Python code.

IMPORTANT SECURITY NOTE:
No browser website can guarantee blocking screenshots, screen recording,
or someone filming the screen with another device. This project removes
normal share/download UI and keeps the storage bucket private, but it cannot
make copied content impossible.

ONLINE SETUP (one-time):
1) Create a Supabase project.
2) In Supabase Storage, create a PRIVATE bucket named:
   private-memories
3) Copy the Supabase project URL.
4) Copy the Supabase SERVICE ROLE key (keep it secret; never post it publicly).
5) Deploy this project to Render as a Python Web Service.
6) Add these environment variables in Render:
   SECRET_KEY = any long random secret (Render can generate this)
   VAULT_PASSWORD = your shared password
   SUPABASE_URL = your Supabase project URL
   SUPABASE_SERVICE_ROLE_KEY = your Supabase service-role key
   SUPABASE_BUCKET = private-memories
7) Deploy. Render will give you the website URL.
8) Open that URL on both phones and enter the same password.

DEFAULT PASSWORD:
NoshUin2026

Change it before using the site for real private files.

WHY SUPABASE:
The previous version stored uploads on the web server. Many free web hosts
can erase server files when a service restarts/redeploys. This version uses a
private Supabase Storage bucket and short-lived signed URLs instead.

The service-role key is extremely sensitive. It must only be stored as a
server environment variable and must never be put in frontend JavaScript,
HTML, GitHub issues, screenshots, or shared with anyone.

LOCAL TEST:
pip install -r requirements.txt
python app.py
then open http://127.0.0.1:5000
If Supabase variables are not present, the app uses local uploads for testing.
